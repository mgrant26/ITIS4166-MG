const express = require('express');
const router = express.Router();
const eventController = require('../controllers/eventController');
const { ensureAuthenticated } = require('../middlewares/auth');

// Routes for creating a new event
router.get('/new', ensureAuthenticated, eventController.renderNewEventForm);
router.post('/new', ensureAuthenticated, eventController.createNewEvent);

// Routes for viewing events
router.get('/', eventController.getAllEvents);
router.get('/:eventId', eventController.getEventDetails);

// Routes for editing and deleting events
router.get('/edit/:eventId', ensureAuthenticated, eventController.renderEditEventForm);
router.post('/edit/:eventId', ensureAuthenticated, eventController.updateEvent);
router.post('/delete/:eventId', ensureAuthenticated, eventController.deleteEvent);

module.exports = router;
