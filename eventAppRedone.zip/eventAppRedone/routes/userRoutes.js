const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const passport = require('passport');
const { ensureAuthenticated } = require('../config/auth');
const User = require('../models/user');
const Event = require('../models/event');

// Login Page
router.get('/login', (req, res) => {
  console.log('Rendering login form');
  res.render('login');
});

// Register Page
router.get('/signup', (req, res) => {
  console.log('Rendering signup form');
  res.render('signup');
});

// Register
router.post('/signup', (req, res) => {
  const { firstName, lastName, email, password, password2 } = req.body;
  console.log(`Signup attempt with email: ${email}`);
  let errors = [];

  if (!firstName || !lastName || !email || !password || !password2) {
    errors.push({ msg: 'Please enter all fields' });
  }

  if (password !== password2) {
    errors.push({ msg: 'Passwords do not match' });
  }

  if (password.length < 6) {
    errors.push({ msg: 'Password must be at least 6 characters' });
  }

  if (errors.length > 0) {
    res.render('signup', { errors, firstName, lastName, email, password, password2 });
  } else {
    User.findOne({ email: email }).then(user => {
      if (user) {
        errors.push({ msg: 'Email already exists' });
        res.render('signup', { errors, firstName, lastName, email, password, password2 });
      } else {
        const newUser = new User({ firstName, lastName, email, password });
        bcrypt.genSalt(10, (err, salt) => {
          bcrypt.hash(newUser.password, salt, (err, hash) => {
            if (err) throw err;
            newUser.password = hash;
            newUser.save().then(user => {
              console.log('New user created:', user);
              req.flash('success_msg', 'You are now registered and can log in');
              res.redirect('/users/login');
            }).catch(err => console.log(err));
          });
        });
      }
    });
  }
});

// Login
router.post('/login', (req, res, next) => {
  console.log(`Login attempt with email: ${req.body.email}`);
  passport.authenticate('local', {
    successRedirect: '/profile',
    failureRedirect: '/users/login',
    failureFlash: true
  })(req, res, next);
});

// Profile
router.get('/profile', ensureAuthenticated, async (req, res) => {
  console.log('Rendering profile page');
  try {
    const events = await Event.find({ user: req.user._id });
    res.render('profile', { user: req.user, events });
  } catch (err) {
    console.error('Error fetching user events:', err);
    res.status(500).render('error', { title: '500 - Internal Server Error', error: err });
  }
});

// Logout
router.get('/logout', (req, res) => {
  console.log('Logging out');
  req.logout();
  req.flash('success_msg', 'You are logged out');
  res.redirect('/users/login');
});

module.exports = router;
