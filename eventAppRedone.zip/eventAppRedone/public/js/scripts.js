document.addEventListener('DOMContentLoaded', (event) => {
    console.log('DOM fully loaded and parsed');
    
    // Example of adding an event listener to a form submission
    const eventForm = document.getElementById('eventForm');
    if (eventForm) {
        eventForm.addEventListener('submit', (e) => {
            e.preventDefault();
            // Add form handling logic here
            console.log('Form submitted');
        });
    }

    // Additional JavaScript functionalities can be added here
});
