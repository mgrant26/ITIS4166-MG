const mongoose = require('mongoose');
const Event = require('./models/event'); // Ensure the path is correct

// Replace with your actual MongoDB Atlas connection string
const mongoURI = 'mongodb+srv://newUser1:12127125@itis4166-mg.36cqfy7.mongodb.net/?retryWrites=true&w=majority&appName=ITIS4166-MG';

mongoose.connect(mongoURI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log('MongoDB connected');
  seedDB();
}).catch(err => {
  console.error('MongoDB connection error:', err);
});

// Seed function to add initial event
const seedDB = async () => {
  try {
    await Event.deleteMany({}); // Clear the collection
    const event = new Event({
      title: 'Test Event',
      category: 'Crab-Focused',
      details: 'This is a test event to ensure everything is working.',
      startDateTime: new Date('2024-06-15T10:00:00'),
      endDateTime: new Date('2024-06-15T12:00:00'),
      location: 'Test Location',
      host: 'Test Host',
      image: '/uploads/crab_meet_and_greet.png'
    });
    await event.save();
    console.log('Seed event created');
    mongoose.connection.close();
  } catch (error) {
    console.error('Error seeding the database:', error);
    mongoose.connection.close();
  }
};
