const User = require('../models/user');
const passport = require('passport');

exports.renderSignupForm = (req, res) => {
  res.render('signup');
};

exports.signup = async (req, res) => {
  try {
    const { firstName, lastName, email, password } = req.body;
    const newUser = new User({ firstName, lastName, email, password });
    await newUser.save();
    res.redirect('/login');
  } catch (error) {
    console.error('Error signing up:', error);
    res.status(500).render('error', { title: '500 - Internal Server Error', error });
  }
};

exports.renderLoginForm = (req, res) => {
  res.render('login');
};

exports.login = passport.authenticate('local', {
  successRedirect: '/profile',
  failureRedirect: '/login',
  failureFlash: true,
});

exports.logout = (req, res) => {
  req.logout(() => {
    res.redirect('/');
  });
};

exports.renderProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user._id).populate('events');
    res.render('profile', { user });
  } catch (error) {
    console.error('Error fetching user profile:', error);
    res.status(500).render('error', { title: '500 - Internal Server Error', error });
  }
};
